<form id="loginForm" action="{{ route('forgotPassword') }}" meyhod="POST">
    <label>Email</label> 
    <input  type="text" name="email_contact">          
    <button type="submit">Submit</button>      
</form>  