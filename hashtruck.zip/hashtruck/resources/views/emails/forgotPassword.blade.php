Hi, {{ $username }}<br><br>
Your requested to reset the password for your Hash Truck account with the email address {{ $email }}.<br>
Your new password is {{ $password }}.<br><br>
Thank You,<br>
Hash Truck