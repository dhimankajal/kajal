<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<meta content="" name="description"/>
<meta content="" name="author"/>
 <?php $__env->startSection('style'); ?>
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/simple-line-icons.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/uniform.default.css')); ?>" rel="stylesheet" type="text/css"/>
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL STYLES -->
<link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/login-soft.css')); ?>" rel="stylesheet" type="text/css"/>
<!-- END PAGE LEVEL SCRIPTS -->
<!-- BEGIN THEME STYLES -->
<link href="<?php echo e(asset('css/components-rounded.css')); ?>" id="style_components" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/plugins.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/layout.css')); ?>" rel="stylesheet" type="text/css"/>
<link id="style_color" href="<?php echo e(asset('css/default.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css"/>
<!-- END THEME STYLES -->
<link rel="shortcut icon" href="favicon.ico"/>
<?php echo $__env->yieldSection(); ?>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="login">
<!-- BEGIN LOGO -->
<div class="logo">
	<a href="index.html">
	<img src="" alt=""/>
	</a>
</div>
<!-- END LOGO -->
<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
<div class="menu-toggler sidebar-toggler">
</div>
<!-- END SIDEBAR TOGGLER BUTTON -->
<!-- BEGIN LOGIN -->
<div class="content">
 <?php echo $__env->yieldContent('content'); ?>
</div>
<!-- END LOGIN -->
<!-- BEGIN COPYRIGHT -->
<div class="copyright">
	 2016 &copy; Pepoolar |Admin Dashbaord Templates
</div>
<!-- END COPYRIGHT -->
<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
<!-- BEGIN CORE PLUGINS -->
<!--[if lt IE 9]>
<script src="../../assets/global/plugins/respond.min.js"></script>
<script src="../../assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery-migrate.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.blockui.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.uniform.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.cokie.min.js')); ?>" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.backstretch.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo e(asset('js/metronic.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/layout.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/demo.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/login-soft.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/message.js')); ?>" type="text/javascript"></script>
<!-- <script src="<?php echo e(asset('js/JqueryValidation/jquery-1.11.3.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/JqueryValidation/jquery.validate.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/JqueryValidation/jquery.form.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/JqueryValidation/custom-validation.js')); ?>" type="text/javascript"></script> -->
<!-- END PAGE LEVEL SCRIPTS -->
<script>
jQuery(document).ready(function() {     
  Metronic.init(); // init metronic core components
Layout.init(); // init current layout
  Login.init();
  Demo.init();
       // init background slide images
       $.backstretch([
        "../img/bg/1.jpg",
        "../img/bg/2.jpg",
        "../img/bg/3.jpg",
        "../img/bg/4.jpg"
        ], {
          fade: 1000,
          duration: 8000
    }
    );
});
</script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>  